package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBMSConnection {

	public final static String DB_DRIVER_CLASS = "com.mysql.cj.jdbc.Driver"; //carica il driver di mysql
	public final static String DB_URL="jdbc:mysql://127.0.0.1:3306/train_stations"; //url sql composto da localhost e il nome del db
	public final static String DB_USERNAME = "root"; //accesso username e password di root
	public final static String DB_PASSWORD = "";
	
	private static Connection conn=null; //creo la variabile di tipo Connection dove genera l'unica connessione

	private static DBMSConnection istanza = null; //creo un attributo istanza utile per il costruttore privato per un'unica connessione
	
	public static Connection getConnessione() { //metodo per ritornare la connessione privata/unica
		return conn;
	}
	
	private DBMSConnection() { //creo il costruttore privato
		
	}
	
	public static synchronized DBMSConnection getIstanza() { //questo metodo genera un'unica istanza dal costruttore privato
		if(istanza == null) {
			istanza = new DBMSConnection();
		}
		
		return istanza;
	}
	
	static { //all'interno del blocco inserisco attributi e metodi statici
		try {
			Class.forName(DB_DRIVER_CLASS); //preparo il driver
			
			conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD); //genero la connessione con l'url e l'admin
		}catch(ClassNotFoundException e1) {
			e1.printStackTrace();
		}catch(SQLException e2) {
			e2.printStackTrace();
		}
	}
}
