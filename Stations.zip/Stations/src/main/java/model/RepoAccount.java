package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBMSConnection;

public class RepoAccount {

	Connection conn = DBMSConnection.getIstanza().getConnessione(); //richiama l'unica connessione per quell'unica istanza
	
	
	public int insertAccount(Account a, int idG, int idP) {
		PreparedStatement ps; //prepara lo statement (query)
		int num = 0;
		String sql = "INSERT INTO `accounts`(`id`, `email`, `username`, `pwd`, `id_gestore`, `id_permesso`) VALUES (?,?,?,?,?,?)";
		
		try {
			ps = conn.prepareStatement(sql); //preparo lo statement passando la stringa
			
			ps.setString(1, a.getId());
			ps.setString(2, a.getEmail());
			ps.setString(3, a.getUsername());
			ps.setString(4, a.getPassword()); //inserisco i valori dall'oggetto alle colonne della tabella gestori indicando la posizione e il valore
			ps.setInt(5, idG);
			ps.setInt(6, idP);
			
			num = ps.executeUpdate(); //eseguo la query DML

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	public int deleteAccount(Account a) {
		PreparedStatement ps; //prepara lo statement (query)
		int num = 0;
		String sql = "DELETE FROM `accounts` WHERE email=?";
		
		try {
			ps = conn.prepareStatement(sql); //preparo lo statement passando la stringa
			
			ps.setString(1, a.getEmail());//inserisco i valori dall'oggetto alle colonne della tabella gestori indicando la posizione e il valore
			
			num = ps.executeUpdate(); //eseguo la query DML

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	
	public int updateAccount(Account a, String old_email, int new_id) {
		PreparedStatement ps; //prepara lo statement (query)
		int num = 0;
		String sql = "UPDATE `accounts` SET `email`=?,`username`=?,`pwd`=?,`id_permesso`=? WHERE email=?";
		
		try {
			ps = conn.prepareStatement(sql); //preparo lo statement passando la stringa
			
			ps.setString(1, a.getEmail());
			ps.setString(2, a.getUsername());
			ps.setString(3, a.getPassword()); //inserisco i valori dall'oggetto alle colonne della tabella gestori indicando la posizione e il valore
			ps.setInt(4, new_id);
			ps.setString(5, old_email);//inserisco il valore dell'email vecchio per modificare quel determinato record
			
			
			num = ps.executeUpdate(); //eseguo la query DML

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	
	public ResultSet getValidUserPwd(Account a) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT tipo, username, pwd FROM accounts JOIN permessi ON(accounts.id_permesso=permessi.id) WHERE username=? AND pwd=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, a.getUsername());
			ps.setString(2, a.getPassword());
			
			rs = ps.executeQuery(); //eseguo la query DQL
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
		
	}
	
	public ResultSet getPermesso(Account a) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT id FROM permessi WHERE tipo=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, a.getTipo_permesso());
			
			rs = ps.executeQuery(); //eseguo la query DQL
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
		
	}
	
	public ResultSet getAccount() {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT g.nome, g.cognome, g.cf, g.data_nascita, g.sesso, a.email, a.username, a.pwd, p.tipo\r\n"
				+ "FROM gestori g inner join accounts a on(g.id=a.id_gestore)\r\n"
				+ "inner join permessi p on(a.id_permesso=p.id)";
		
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getAccount(Account a) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT g.nome, g.cognome, g.cf, g.data_nascita, g.sesso, a.email, a.username, a.pwd, p.tipo\r\n"
				+ "FROM gestori g inner join accounts a on(g.id=a.id_gestore)\r\n"
				+ "inner join permessi p on(a.id_permesso=p.id) WHERE a.username=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, a.getUsername());
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getAccount(Gestore g) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT email FROM gestori inner join accounts on(gestori.id=accounts.id_gestore) WHERE cf=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, g.getCf());
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getAccount(String cf) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT g.nome, g.cognome, g.cf, g.data_nascita, g.sesso, a.id, a.email, a.username, a.pwd, p.tipo "
				+ "FROM gestori g inner join accounts a on(g.id=a.id_gestore) "
				+ "inner join permessi p on(a.id_permesso=p.id) WHERE g.cf=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, cf);
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}

}
