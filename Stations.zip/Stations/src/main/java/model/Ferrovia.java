package model;

import java.sql.Date;
import java.sql.Time;
import java.util.Objects;

public class Ferrovia {

	private String nome_compagnia;
	private String nome_modello;  //tabella sql compagnia
	private Date anno_fondazione;
	
	private String nome_serie;
	private Date anno_produzione;
	private int velocita_max;  //tabella sql treno 
	private int capacita_pas;
	private int capacita_mer;

	private String id_tipo;
	private String nome_tipo;  //tabella sql tipo
	private String descrizione;
	
	private String nome_stazione;
	private String localita;  //tabella sql stazione
	private Date anno_apertura;
	
	private int binario;  //tabella sql binario
	
	private String status;  //tabella sql tabellone (restante)
	private Time orario;
	
	
	public String getNome_compagnia() {
		return nome_compagnia;
	}
	public void setNome_compagnia(String nome_compagnia) {
		this.nome_compagnia = nome_compagnia;
	}
	public String getNome_modello() {
		return nome_modello;
	}
	public void setNome_modello(String nome_modello) {
		this.nome_modello = nome_modello;
	}
	public Date getAnno_fondazione() {
		return anno_fondazione;
	}
	public void setAnno_fondazione(Date anno_fondazione) {
		this.anno_fondazione = anno_fondazione;
	}
	public String getNome_serie() {
		return nome_serie;
	}
	public void setNome_serie(String nome_serie) {
		this.nome_serie = nome_serie;
	}
	public Date getAnno_produzione() {
		return anno_produzione;
	}
	public void setAnno_produzione(Date anno_produzione) {
		this.anno_produzione = anno_produzione;
	}
	public int getVelocita_max() {
		return velocita_max;
	}
	public void setVelocita_max(int velocita_max) {
		this.velocita_max = velocita_max;
	}
	public int getCapacita_pas() {
		return capacita_pas;
	}
	public void setCapacita_pas(int capacita_pas) {
		this.capacita_pas = capacita_pas;
	}
	public int getCapacita_mer() {
		return capacita_mer;
	}
	public void setCapacita_mer(int capacita_mer) {
		this.capacita_mer = capacita_mer;
	}
	public String getId_tipo() {
		return id_tipo;
	}
	public void setId_tipo(String id_tipo) {
		this.id_tipo = id_tipo;
	}
	public String getNome_tipo() {
		return nome_tipo;
	}
	public void setNome_tipo(String nome_tipo) {
		this.nome_tipo = nome_tipo;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public String getNome_stazione() {
		return nome_stazione;
	}
	public void setNome_stazione(String nome_stazione) {
		this.nome_stazione = nome_stazione;
	}
	public String getLocalita() {
		return localita;
	}
	public void setLocalita(String localita) {
		this.localita = localita;
	}
	public Date getAnno_apertura() {
		return anno_apertura;
	}
	public void setAnno_apertura(Date anno_apertura) {
		this.anno_apertura = anno_apertura;
	}
	public int getBinario() {
		return binario;
	}
	public void setBinario(int binario) {
		this.binario = binario;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Time getOrario() {
		return orario;
	}
	public void setOrario(Time orario) {
		this.orario = orario;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(anno_apertura, anno_fondazione, anno_produzione, binario, capacita_mer, capacita_pas,
				descrizione, id_tipo, localita, nome_compagnia, nome_modello, nome_serie, nome_stazione, nome_tipo,
				orario, status, velocita_max);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ferrovia other = (Ferrovia) obj;
		return Objects.equals(anno_apertura, other.anno_apertura)
				&& Objects.equals(anno_fondazione, other.anno_fondazione)
				&& Objects.equals(anno_produzione, other.anno_produzione) && binario == other.binario
				&& capacita_mer == other.capacita_mer && capacita_pas == other.capacita_pas
				&& Objects.equals(descrizione, other.descrizione) && Objects.equals(id_tipo, other.id_tipo)
				&& Objects.equals(localita, other.localita) && Objects.equals(nome_compagnia, other.nome_compagnia)
				&& Objects.equals(nome_modello, other.nome_modello) && Objects.equals(nome_serie, other.nome_serie)
				&& Objects.equals(nome_stazione, other.nome_stazione) && Objects.equals(nome_tipo, other.nome_tipo)
				&& Objects.equals(orario, other.orario) && Objects.equals(status, other.status)
				&& velocita_max == other.velocita_max;
	}
	public Ferrovia() {
		
	}
	
	public Ferrovia(String nome_compagnia, String nome_modello, Date anno_fondazione, String nome_serie,
			Date anno_produzione, int velocita_max, int capacita_pas, int capacita_mer, String id_tipo, String nome_tipo,
			String descrizione, String nome_stazione, String localita, Date anno_apertura, int binario, String status,
			Time orario) {
		super();
		this.nome_compagnia = nome_compagnia;
		this.nome_modello = nome_modello;
		this.anno_fondazione = anno_fondazione;
		this.nome_serie = nome_serie;
		this.anno_produzione = anno_produzione;
		this.velocita_max = velocita_max;
		this.capacita_pas = capacita_pas;
		this.capacita_mer = capacita_mer;
		this.id_tipo = id_tipo;
		this.nome_tipo = nome_tipo;
		this.descrizione = descrizione;
		this.nome_stazione = nome_stazione;
		this.localita = localita;
		this.anno_apertura = anno_apertura;
		this.binario = binario;
		this.status = status;
		this.orario = orario;
	}
	
}
