package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBMSConnection;

public class RepoTreno {

	Connection conn = DBMSConnection.getIstanza().getConnessione();
	
	public int insertTreno(Ferrovia f) {
		PreparedStatement ps;
		int num = 0;
		String sql = "INSERT INTO `treni`(`nome_serie`, `anno_produzione`, `velocita_max`, `capacita_pas`, `capacita_mer`) VALUES (?,?,?,?,?)";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, f.getNome_serie());
			ps.setDate(2, f.getAnno_produzione());
			ps.setInt(3, f.getVelocita_max());
			ps.setInt(4, f.getCapacita_pas());
			ps.setInt(5, f.getCapacita_mer());
			
			num = ps.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	
	public ResultSet getIndTreno(Ferrovia f) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT `id` FROM `treni` WHERE `nome_serie`=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, f.getNome_serie());
			
			rs = ps.executeQuery(); //esegue query DQL
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getSerieTreno(int indice) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT `nome_serie` FROM `treni` WHERE `id`=?;";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, indice);
			
			rs = ps.executeQuery(); //esegue query DQL
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
}
