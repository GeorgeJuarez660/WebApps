package model;

import java.sql.Date;
import java.util.Objects;

public class Gestore {

	private String nome;
	private String cognome;
	private Date data_nascita;
	private String cf;
	private String sesso;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public Date getData_nascita() {
		return data_nascita;
	}
	public void setData_nascita(Date data_nascita) {
		this.data_nascita = data_nascita;
	}
	public String getCf() {
		return cf;
	}
	public void setCf(String cf) {
		this.cf = cf;
	}
	public String getSesso() {
		return sesso;
	}
	public void setSesso(String sesso) {
		this.sesso = sesso;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(cf, cognome, data_nascita, nome, sesso);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Gestore other = (Gestore) obj;
		return Objects.equals(cf, other.cf) && Objects.equals(cognome, other.cognome)
				&& Objects.equals(data_nascita, other.data_nascita) && Objects.equals(nome, other.nome)
				&& Objects.equals(sesso, other.sesso);
	}
	
	
	public Gestore() {
		
	}
	
	public Gestore(String nome, String cognome, Date data_nascita, String cf, String sesso) {
		super();
		this.nome = nome;
		this.cognome = cognome;
		this.data_nascita = data_nascita;
		this.cf = cf;
		this.sesso = sesso;
	}
	
}
