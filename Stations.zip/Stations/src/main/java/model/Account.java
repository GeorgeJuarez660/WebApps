package model;

import java.util.Objects;

public class Account {

	private String id;
	private String email;
	private String username;
	private String password;
	private String tipo_permesso;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTipo_permesso() {
		return tipo_permesso;
	}
	public void setTipo_permesso(String tipo_permesso) {
		this.tipo_permesso = tipo_permesso;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(email, id, password, tipo_permesso, username);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		return Objects.equals(email, other.email) && Objects.equals(id, other.id)
				&& Objects.equals(password, other.password) && Objects.equals(tipo_permesso, other.tipo_permesso)
				&& Objects.equals(username, other.username);
	}
	
	
	public Account() {
		
	}
	
	public Account(String id, String email, String username, String password, String tipo_permesso) {
		super();
		this.id = id;
		this.email = email;
		this.username = username;
		this.password = password;
		this.tipo_permesso = tipo_permesso;
	}

	
	
	
	
}
