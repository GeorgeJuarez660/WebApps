package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBMSConnection;

public class RepoTabellone {

	Connection conn = DBMSConnection.getIstanza().getConnessione();
	
	public int insertTabellone(Ferrovia f, int IDC, int IDT, int IDD, int IDA, Account a) {
		PreparedStatement ps;
		int num = 0;
		String sql = "INSERT INTO `tabellone`(`id_compagnia`, `id_treno`, `id_tipo`, `id_stazione_par`, `id_stazione_arr`, `es_status`, `orario`, `id_binario`, `acc`) VALUES (?,?,?,?,?,?,?,?,?);";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, IDC);
			ps.setInt(2, IDT);
			ps.setString(3, f.getId_tipo());
			ps.setInt(4, IDD);
			ps.setInt(5, IDA);
			ps.setString(6, f.getStatus());
			ps.setTime(7, f.getOrario());
			
			if(f.getBinario()==0) {
				ps.setString(8, null);
			}
			else {
				ps.setInt(8, f.getBinario());
			}
			ps.setString(9, a.getId());
			
			num = ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	public ResultSet getInfoTabellone() {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT tab.id, c.nome, tr.nome_serie, tab.id_tipo, st1.nome, st2.nome, tab.es_status, tab.orario, tab.id_binario, tab.acc "
				+ "FROM compagnie c inner join tabellone tab on(c.id=tab.id_compagnia) "
				+ "inner join treni tr on(tab.id_treno=tr.id) "
				+ "inner join stazioni st1 on(tab.id_stazione_par=st1.id) "
				+ "inner join stazioni st2 on(tab.id_stazione_arr=st2.id)";
		
		try {
			ps = conn.prepareStatement(sql);
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getInfoTabellone(DTO d) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT tab.id, c.nome, tr.nome_serie, tab.id_tipo, st1.nome, st2.nome, tab.es_status, tab.orario, tab.id_binario, tab.acc "
				+ "FROM compagnie c inner join tabellone tab on(c.id=tab.id_compagnia) "
				+ "inner join treni tr on(tab.id_treno=tr.id) "
				+ "inner join stazioni st1 on(tab.id_stazione_par=st1.id) "
				+ "inner join stazioni st2 on(tab.id_stazione_arr=st2.id) where tab.id=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, d.getId_tab());
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getIndexC(DTO d) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT c.id "
				+ "FROM compagnie c "
				+ "where c.nome=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, d.getNome_compagnia());
			
			rs = ps.executeQuery();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getIndexS(DTO d) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "select tr.id "
				+ "from treni tr "
				+ "where tr.nome_serie=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, d.getNome_serie());
			
			rs = ps.executeQuery();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getIndexD(DTO d) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "select st1.id "
				+ "from stazioni st1 "
				+ "where st1.nome=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, d.getNome_stazione_par());
			
			rs = ps.executeQuery();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getIndexA(DTO d) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "select st2.id "
				+ "from stazioni st2 "
				+ "where st2.nome=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, d.getNome_stazione_arr());
			
			rs = ps.executeQuery();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public int deleteInfoTabellone(DTO d) {
		PreparedStatement ps;
		int num = 0;
		String sql ="DELETE FROM `tabellone` WHERE `id`=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, d.getId_tab());
			
			num = ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	
	
	public int updateInfoTabellone(DTO d, int indC, int indS, int indD, int indA) {
		PreparedStatement ps;
		int num = 0;
		String sql = "UPDATE `tabellone` SET `id_compagnia`=?, `id_treno`=?, `id_tipo`=?, "
				+ "`id_stazione_par`=?, `id_stazione_arr`=?, `es_status`=?, `orario`=?, "
				+ "`id_binario`=?, `acc`=? WHERE `id`=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, indC);
			ps.setInt(2, indS);
			ps.setString(3, d.getId_tipo());
			ps.setInt(4, indD);
			ps.setInt(5, indA);
			ps.setString(6, d.getStatus());
			ps.setTime(7, d.getOrario());
			ps.setInt(8, d.getBinario());
			ps.setString(9, d.getId());
			ps.setInt(10, d.getId_tab());
			
			num = ps.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
}
