package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import util.DBMSConnection;

public class RepoBinario {
	
	Connection conn = DBMSConnection.getIstanza().getConnessione();
	
	public int insertBinario(Ferrovia f) {
		PreparedStatement ps;
		int num = 0;
		String sql = "INSERT INTO `binari`(`numero`) VALUES (?)";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, f.getBinario());
			
			num = ps.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}

}
