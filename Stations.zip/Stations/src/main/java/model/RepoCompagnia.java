package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBMSConnection;

public class RepoCompagnia {
	
	Connection conn = DBMSConnection.getIstanza().getConnessione();
	
	public int insertCompagnia(Ferrovia f) {
		PreparedStatement ps;
		int num = 0;
		String sql = "INSERT INTO `compagnie`(`nome`, `anno_fondazione`) VALUES (?,?)";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, f.getNome_compagnia());
			ps.setDate(2, f.getAnno_fondazione());
			
			num = ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	
	public ResultSet getIndCompagnia(Ferrovia f) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT `id` FROM `compagnie` WHERE `nome`=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, f.getNome_compagnia());
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getNomeCompagnia(int indice) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT `nome` FROM `compagnie` WHERE `id`=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, indice);
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}

}
