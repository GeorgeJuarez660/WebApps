package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBMSConnection;

public class RepoStazione {
	
	Connection conn = DBMSConnection.getIstanza().getConnessione();
	
	public int insertStazione(Ferrovia f) {
		PreparedStatement ps;
		int num=0;
		String sql = "INSERT INTO `stazioni`(`nome`, `localita`, `anno_apertura`) VALUES (?,?,?)";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, f.getNome_stazione());
			ps.setString(2, f.getLocalita());
			ps.setDate(3, f.getAnno_apertura());
			
			num = ps.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
		
	}
	
	
	public ResultSet getIndStazione(String stazione) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT `id` FROM `stazioni` WHERE `nome`=?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, stazione);
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getNomeStazione(int indice) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT `nome` FROM `stazioni` WHERE `id`=?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, indice);
			
			rs = ps.executeQuery();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}

}
