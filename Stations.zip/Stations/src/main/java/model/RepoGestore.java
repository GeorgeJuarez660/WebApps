package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBMSConnection;

public class RepoGestore {
	
	Connection conn = DBMSConnection.getIstanza().getConnessione(); //richiama l'unica connessione per quell'unica istanza
	
	public int insertGestore(Gestore g) {
		PreparedStatement ps; //prepara lo statement (query)
		int num = 0;
		String sql = "INSERT INTO `gestori`(`nome`, `cognome`, `cf`, `data_nascita`, `sesso`) VALUES (?,?,?,?,?)";
		
		try {
			ps = conn.prepareStatement(sql); //preparo lo statement passando la stringa
			
			ps.setString(1, g.getNome());
			ps.setString(2, g.getCognome());
			ps.setString(3, g.getCf()); //inserisco i valori dall'oggetto alle colonne della tabella gestori indicando la posizione e il valore
			ps.setDate(4, g.getData_nascita());
			ps.setString(5, g.getSesso());
			
			num = ps.executeUpdate(); //eseguo la query DML

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	public int deleteGestore(Gestore g) {
		PreparedStatement ps; //prepara lo statement (query)
		int num = 0;
		String sql = "DELETE FROM gestori WHERE cf=?";
		
		try {
			ps = conn.prepareStatement(sql); //preparo lo statement passando la stringa
			
			ps.setString(1, g.getCf());//inserisco i valori dall'oggetto alle colonne della tabella gestori indicando la posizione e il valore
			
			num = ps.executeUpdate(); //eseguo la query DML

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	
	public int updateGestore(Gestore g, String cf) {
		PreparedStatement ps; //prepara lo statement (query)
		int num = 0;
		String sql = "UPDATE `gestori` SET `nome`=?,`cognome`=?,`cf`=?,`data_nascita`=?,`sesso`=? WHERE cf=?";
		
		try {
			ps = conn.prepareStatement(sql); //preparo lo statement passando la stringa
			
			ps.setString(1, g.getNome());
			ps.setString(2, g.getCognome());
			ps.setString(3, g.getCf()); //inserisco i valori dall'oggetto alle colonne della tabella gestori indicando la posizione e il valore
			ps.setDate(4, g.getData_nascita());
			ps.setString(5, g.getSesso());
			
			ps.setString(6, cf); //inserisco il valore del cf vecchio per modificare quel determinato record
			
			num = ps.executeUpdate(); //eseguo la query DML

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	public ResultSet getGestore(Gestore g) {
		PreparedStatement ps;
		ResultSet rs = null;
		String sql = "SELECT id FROM gestori WHERE cf=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, g.getCf());
			
			rs = ps.executeQuery(); //eseguo la query DQL
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}

}
