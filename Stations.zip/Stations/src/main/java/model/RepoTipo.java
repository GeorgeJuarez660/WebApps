package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import util.DBMSConnection;

public class RepoTipo {
	
	Connection conn = DBMSConnection.getIstanza().getConnessione();
	
	public int insertTipo(Ferrovia f) {
		PreparedStatement ps;
		int num = 0;
		String sql = "INSERT INTO `tipi`(`id`, `nome`, `descrizione`) VALUES (?,?,?)";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, f.getId_tipo());
			ps.setString(2, f.getNome_modello());
			ps.setString(3, f.getDescrizione());
			
			num = ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}

}
