package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Ferrovia;
import model.RepoStazione;

import java.io.IOException;
import java.sql.Date;

/**
 * Servlet implementation class InsertStation
 */
public class InsertStation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertStation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Ferrovia f = new Ferrovia();
		RequestDispatcher rd;
		
		f.setNome_stazione(request.getParameter("name"));
		f.setLocalita(request.getParameter("city"));
		f.setAnno_apertura(Date.valueOf(request.getParameter("date")));
		
		RepoStazione rs = new RepoStazione();
		
		if(rs.insertStazione(f)>0) {
			request.setAttribute("msg", "STAZIONE INSERITA CON SUCCESSO");
			rd = request.getRequestDispatcher("SuccessFile.jsp");
			rd.forward(request, response);
		}
		else {
			request.setAttribute("msg", "INSERIMENTO STAZIONE FALLITO");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
		
		
	}

}
