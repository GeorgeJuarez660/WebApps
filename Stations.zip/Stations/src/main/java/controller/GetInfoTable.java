package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.DTO;
import model.RepoTabellone;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Servlet implementation class GetInfoTable
 */
public class GetInfoTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetInfoTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RepoTabellone rtab = new RepoTabellone();
		DTO d;
		ResultSet rs;
		RequestDispatcher rd;
		ArrayList<DTO> arrDTO = new ArrayList<DTO>();

		rs = rtab.getInfoTabellone();
		
		try {
			while(rs.next()) {
				d = new DTO();
				d.setId_tab(rs.getInt("tab.id"));
				d.setNome_compagnia(rs.getString("c.nome"));
				d.setNome_serie(rs.getString("tr.nome_serie"));
				d.setNome_tipo(rs.getString("tab.id_tipo"));
				d.setNome_stazione_par(rs.getString("st1.nome"));
				d.setNome_stazione_arr(rs.getString("st2.nome"));
				d.setStatus(rs.getString("tab.es_status"));
				d.setOrario(rs.getTime("tab.orario"));
				d.setBinario(rs.getInt("tab.id_binario"));
				d.setId(rs.getString("tab.acc"));
				
				arrDTO.add(d);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("tab", arrDTO);
		rd = request.getRequestDispatcher("GetInfoTableFile.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
