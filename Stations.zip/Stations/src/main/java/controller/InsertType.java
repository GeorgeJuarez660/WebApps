package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Ferrovia;
import model.RepoTipo;

import java.io.IOException;

/**
 * Servlet implementation class InsertType
 */
public class InsertType extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertType() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Ferrovia f = new Ferrovia();
		RequestDispatcher rd;
		
		f.setId_tipo(request.getParameter("id"));
		f.setNome_modello(request.getParameter("name"));
		f.setDescrizione(request.getParameter("desc"));
		
		RepoTipo rt = new RepoTipo();
		
		if(rt.insertTipo(f)>0) {
			
			request.setAttribute("msg", "TIPO INSERITO CON SUCCESSO");
			rd = request.getRequestDispatcher("SuccessFile.jsp");
			rd.forward(request, response);
		}
		else {
			request.setAttribute("msg", "INSERIMENTO TIPO FALLITO");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
	}

}
