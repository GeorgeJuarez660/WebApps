package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.DTO;
import model.RepoTabellone;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

/**
 * Servlet implementation class UpdateInfoTable
 */
public class UpdateInfoTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateInfoTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		DTO d = new DTO();
		RepoTabellone rt = new RepoTabellone();
		RequestDispatcher rd;
		
		d.setId_tab(Integer.parseInt(request.getParameter("id")));
		
		ResultSet rs= rt.getInfoTabellone(d);
		
		
		d = new DTO();
		try {
			if(rs.next()) {
				d.setId_tab(rs.getInt("tab.id"));
				d.setNome_compagnia(rs.getString("c.nome"));
				d.setNome_serie(rs.getString("tr.nome_serie"));
				d.setNome_tipo(rs.getString("tab.id_tipo"));
				d.setNome_stazione_par(rs.getString("st1.nome"));
				d.setNome_stazione_arr(rs.getString("st2.nome"));
				d.setStatus(rs.getString("tab.es_status"));
				d.setOrario(rs.getTime("tab.orario"));
				d.setBinario(rs.getInt("tab.id_binario"));
				d.setId(rs.getString("tab.acc"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("IU", 1);
		request.setAttribute("tab", d);
		rd = request.getRequestDispatcher("InsertInfoTableFile.jsp");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPut(request, response);
	}
	//Richiesta di modifica
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		DTO d_old = new DTO();
		DTO d_new = new DTO();
		RequestDispatcher rd;
		
		d_old.setId_tab(Integer.parseInt(request.getParameter("id_old")));
		d_old.setNome_compagnia(request.getParameter("company_old"));
		d_old.setNome_serie(request.getParameter("series_old"));
		d_old.setId_tipo(request.getParameter("type_old"));
		d_old.setNome_stazione_par(request.getParameter("depst_old"));
		d_old.setNome_stazione_arr(request.getParameter("arrst_old"));
		d_old.setStatus(request.getParameter("status_old"));
		d_old.setOrario(Time.valueOf(request.getParameter("time_old")));
		d_old.setBinario(Integer.parseInt(request.getParameter("track_old")));
		d_old.setId(request.getParameter("acc_old"));
		
		String company = request.getParameter("company");
		String series = request.getParameter("series");
		String type = request.getParameter("type");
		String depst = request.getParameter("depst");
		String arrst = request.getParameter("arrst");
		String status = request.getParameter("status");
		String id = request.getParameter("acc");
		
		
		d_new.setId_tab(d_old.getId_tab());
		
		if(!company.isEmpty()) {
			d_new.setNome_compagnia(company);
		}
		else {
			d_new.setNome_compagnia(d_old.getNome_compagnia());
		}
		
		if(!series.isEmpty()) {
			d_new.setNome_serie(series);
		}
		else {
			d_new.setNome_serie(d_old.getNome_serie());
		}
		
		if(!type.isEmpty()) {
			d_new.setId_tipo(type);
		}
		else {
			d_new.setId_tipo(d_old.getId_tipo());
		}
		
		if(!depst.isEmpty()) {
			d_new.setNome_stazione_par(depst);
		}
		else {
			d_new.setNome_stazione_par(d_old.getNome_stazione_par());
		}
		
		if(!arrst.isEmpty()) {
			d_new.setNome_stazione_arr(arrst);
		}
		else {
			d_new.setNome_stazione_arr(d_old.getNome_stazione_arr());
		}
		
		if(!status.isEmpty()) {
			d_new.setStatus(status);
			
			if(d_new.getStatus().equals("E") || d_new.getStatus().equals("R")) {
				String h = request.getParameter("hours");
				String m = request.getParameter("minutes");
				String s = request.getParameter("seconds");
				
				if(!h.isEmpty() && !m.isEmpty() && !s.isEmpty()) {
					String time = h + ":" + m + ":" + s;
					
					d_new.setOrario(Time.valueOf(time));
				}
				else {
					d_new.setOrario(d_old.getOrario());
				}
				
				String track = request.getParameter("track");
				
				if(!track.isEmpty()) {
					d_new.setBinario(Integer.parseInt(track));
				}
				else {
					d_new.setBinario(d_old.getBinario());
				}
				
			}
			else {
				System.out.println("NO TIME NO TRACK");
			}
		}
		else {
			d_new.setStatus(d_old.getStatus());
		}
		
		if(!id.isEmpty()) {
			d_new.setId(id);
		}
		else {
			d_new.setId(d_old.getId());
		}
		
		
		if(d_new.equals(d_old)) { //controlla se le stringe di due oggetti sono uguali (come l'indirizzo di memoria)
			request.setAttribute("msg", "MODIFICA INFO TABELLONE ANNULLATA");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
		else {
			ResultSet rs;
			RepoTabellone rt = new RepoTabellone();
			
			rs = rt.getIndexC(d_new);
			int indC = 0, indS = 0, indD = 0, indA = 0;
			
			try {
				if(rs.next()) {
					indC = rs.getInt("c.id");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			rs = rt.getIndexS(d_new);
			
			try {
				if(rs.next()) {
					indS = rs.getInt("tr.id");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			rs = rt.getIndexD(d_new);
			
			try {
				if(rs.next()) {
					indD = rs.getInt("st1.id");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			rs = rt.getIndexA(d_new);
			
			try {
				if(rs.next()) {
					indA = rs.getInt("st2.id");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			if(indC > 0 && indS > 0 && indD > 0 && indA > 0) {
				
				if(rt.updateInfoTabellone(d_new, indC, indS, indD, indA)>0) {
					request.setAttribute("msg", "INFO TABELLONE MODIFICATO CON SUCCESSO");
					rd = request.getRequestDispatcher("SuccessFile.jsp");
					rd.forward(request, response);
				}
				else {
					request.setAttribute("msg", "MODIFICA INFO TABELLONE FALLITA");
					rd = request.getRequestDispatcher("ErrorFile.jsp");
					rd.forward(request, response);
				}
			}
			else {
				request.setAttribute("msg", "INDEX INVALIDI");
				rd = request.getRequestDispatcher("ErrorFile.jsp");
				rd.forward(request, response);
			}
		}
	}

}
