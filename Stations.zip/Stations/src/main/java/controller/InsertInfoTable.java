package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Account;
import model.Ferrovia;
import model.RepoCompagnia;
import model.RepoStazione;
import model.RepoTabellone;
import model.RepoTipo;
import model.RepoTreno;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

/**
 * Servlet implementation class InsertInfoTable
 */
public class InsertInfoTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertInfoTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Ferrovia f = new Ferrovia();
		Account a = new Account();
		RequestDispatcher rd;
		ResultSet rset;
		
		f.setNome_compagnia(request.getParameter("company"));
		f.setNome_serie(request.getParameter("series"));
		f.setId_tipo(request.getParameter("type"));
		String staz_par = request.getParameter("depst");
		String staz_arr = request.getParameter("arrst");
		f.setStatus(request.getParameter("status"));
		
		if(f.getStatus().equals("E") || f.getStatus().equals("R")) {
			String h = request.getParameter("hours");
			String m = request.getParameter("minutes");
			String s = request.getParameter("seconds");
			String time = h + ":" + m + ":" + s;
			f.setOrario(Time.valueOf(time));
			f.setBinario(Integer.parseInt(request.getParameter("track")));		
			System.out.println("TIME: " +f.getOrario());
		}
		else {
			System.out.println("NO TIME NO TRACK");
		}
		
		a.setId(request.getParameter("acc"));
		
		
		RepoCompagnia rc = new RepoCompagnia();
		RepoTreno rtr = new RepoTreno();
		RepoStazione rs = new RepoStazione();
		
		rset = rc.getIndCompagnia(f);
		int IDCompagnia = 0;
		
		try {
			if(rset.next()) {
				IDCompagnia = rset.getInt("id");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		rset = rtr.getIndTreno(f);
		int IDTreno = 0;
		
		try {
			if(rset.next()) {
				IDTreno = rset.getInt("id");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		rset = rs.getIndStazione(staz_par);
		int IDStaz_par = 0;
		
		try {
			if(rset.next()) {
				IDStaz_par = rset.getInt("id");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		rset = rs.getIndStazione(staz_arr);
		int IDStaz_arr = 0;
		
		try {
			if(rset.next()) {
				IDStaz_arr = rset.getInt("id");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		if(IDCompagnia != 0 && IDTreno != 0 && IDStaz_par != 0 && IDStaz_arr != 0){
			RepoTabellone rt = new RepoTabellone();
			
			if(rt.insertTabellone(f, IDCompagnia, IDTreno, IDStaz_par, IDStaz_arr, a)>0) {
				request.setAttribute("msg", "INFO TABELLONE INSERITA CON SUCCESSO");
				rd = request.getRequestDispatcher("SuccessFile.jsp");
				rd.forward(request, response);
			}
			else {
				request.setAttribute("msg", "INSERIMENTO INFO TABELLONE FALLITO");
				rd = request.getRequestDispatcher("ErrorFile.jsp");
				rd.forward(request, response);
			}
		}
		else {
			request.setAttribute("msg", "UNO DEGLI INDICI NON È PRESENTE");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
	}

}
