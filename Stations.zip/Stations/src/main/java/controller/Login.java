package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Account;
import model.RepoAccount;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//jakarta.servlet.http è l'ultima versione di session e requestdispatcher per via dell'ultima versione di maven project
		jakarta.servlet.http.HttpSession session = request.getSession();
		
		Account a = new Account();
		RepoAccount ra = new RepoAccount();
		ResultSet rs;
		RequestDispatcher rd;
		
		a.setUsername(request.getParameter("username"));
		a.setPassword(request.getParameter("password"));
		
	    rs = ra.getValidUserPwd(a);
	    
	    a = new Account(); //è importante creare una nuova istanza a scop globale, altrimenti prende i valori vecchi inseriti
	    try {
	    	if(rs.next()) {
	    		a.setUsername(rs.getString("username"));
	    		a.setPassword(rs.getString("pwd"));
	    		a.setTipo_permesso(rs.getString("tipo"));
	    	}
	    }catch(SQLException e) {
	    	e.printStackTrace();
	    }
	    
	    if(a.getUsername() != null && a.getPassword() != null) {
	    	
	    	session.setAttribute("sessionRole", a);
	    	request.setAttribute("msg", "LOGIN EFFETTUATO CON SUCCESSO");
	    	rd = request.getRequestDispatcher("SuccessFile.jsp");
	    	rd.forward(request, response);
	    	
	    }
	    else {
	    	request.setAttribute("msg", "USERNAME E/O PASSWORD INVALIDI");
	    	rd = request.getRequestDispatcher("ErrorLoginFile.jsp");
	    	rd.forward(request, response);
	    	
	    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
