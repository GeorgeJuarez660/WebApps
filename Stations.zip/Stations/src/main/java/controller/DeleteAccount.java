package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Account;
import model.Gestore;
import model.RepoAccount;
import model.RepoGestore;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class DeleteAccount
 */
public class DeleteAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteAccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doDelete(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}
	
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Gestore g = new Gestore();
		Account a = new Account();
		
		g.setCf(request.getParameter("cf"));
		
		RepoGestore rg = new RepoGestore();
		RepoAccount ra = new RepoAccount();
		RequestDispatcher rd;
		ResultSet rs;
		
		rs = ra.getAccount(g);
		
		try {
			if(rs.next()) {
				a.setEmail(rs.getString("email"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		
		
		if(ra.deleteAccount(a)>0) {
			if(rg.deleteGestore(g)>0) {
				request.setAttribute("msg", "GESTORE E ACCOUNT ELIMINATI CON SUCCESSO");
				rd = request.getRequestDispatcher("SuccessFile.jsp");
				rd.forward(request, response);
			}
			else {
				request.setAttribute("msg", "ELIMINAZIONE GESTORE FALLITA");
				rd = request.getRequestDispatcher("ErrorFile.jsp");
				rd.forward(request, response);
			}	
		}
		else {
			request.setAttribute("msg", "ELIMINAZIONE ACCOUNT FALLITA");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
	}

}
