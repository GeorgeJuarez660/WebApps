package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.DTO;
import model.RepoTabellone;

import java.io.IOException;

/**
 * Servlet implementation class DeleteInfoTable
 */
public class DeleteInfoTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteInfoTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doDelete(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}
	//metodo per effettuare richiesta di eliminazione
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		DTO d = new DTO();
		
		d.setId_tab(Integer.parseInt(request.getParameter("id")));
		
		RepoTabellone rt = new RepoTabellone();
		RequestDispatcher rd;
		
		if(rt.deleteInfoTabellone(d)>0) {
			request.setAttribute("msg", "INFO TABELLONE ELIMINATA CON SUCCESSO");
			rd = request.getRequestDispatcher("SuccessFile.jsp");
			rd.forward(request, response);
		}
		else {
			request.setAttribute("msg", "ELIMINAZIONE INFO TABELLONE FALLITA");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
		
		
	}

}
