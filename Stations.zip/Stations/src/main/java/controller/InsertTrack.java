package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Ferrovia;
import model.RepoBinario;

import java.io.IOException;

/**
 * Servlet implementation class InsertTrack
 */
public class InsertTrack extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertTrack() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Ferrovia f = new Ferrovia();
		RequestDispatcher rd;
		
		f.setBinario(Integer.parseInt(request.getParameter("number"))); //richiesta dal parametro e lo converto in intero
		
		RepoBinario rb = new RepoBinario();
		
		if(rb.insertBinario(f)>0) {
			request.setAttribute("msg", "BINARIO INSERTITO CON SUCCESSO");
			rd = request.getRequestDispatcher("SuccessFile.jsp");
			rd.forward(request, response);
		}
		else {
			request.setAttribute("msg", "INSERIMENTO BINARIO FALLITO");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
	}

}
