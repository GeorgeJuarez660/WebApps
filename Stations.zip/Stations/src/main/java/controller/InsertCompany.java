package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Ferrovia;
import model.RepoCompagnia;

import java.io.IOException;
import java.sql.Date;

/**
 * Servlet implementation class InsertCompany
 */
public class InsertCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Ferrovia f = new Ferrovia();
		RequestDispatcher rd;
		
		f.setNome_compagnia(request.getParameter("name"));
		f.setAnno_fondazione(Date.valueOf(request.getParameter("date")));
		
		RepoCompagnia rc = new RepoCompagnia();
		
		if(rc.insertCompagnia(f)>0) {
			request.setAttribute("msg", "COMPAGNIA INSERITA CON SUCCESSO");
			rd = request.getRequestDispatcher("SuccessFile.jsp");
			rd.forward(request, response);
		}
		else {
			request.setAttribute("msg", "INSERIMENTO COMPAGNIA FALLITO");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
	}

}
