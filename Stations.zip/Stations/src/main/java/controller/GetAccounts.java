package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Account;
import model.DTO;
import model.Gestore;
import model.RepoAccount;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Servlet implementation class GetAccounts
 */
public class GetAccounts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAccounts() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Gestore g;
		Account a = new Account();
		DTO d;
		RepoAccount ra = new RepoAccount();
		ResultSet rs;
		RequestDispatcher rd;
		
		HttpSession session = request.getSession();
		
		a = (Account) session.getAttribute("sessionRole");
		
		if(a != null) {
			if(a.getTipo_permesso().equals("ADMIN")) {
				ArrayList<DTO> arrADDTO = new ArrayList<DTO>();
				rs = ra.getAccount();
				
				try {
					while(rs.next()) {
						d = new DTO();
						d.setNome(rs.getString("g.nome"));
						d.setCognome(rs.getString("g.cognome"));
						d.setCf(rs.getString("g.cf"));
						d.setData_nascita(rs.getDate("g.data_nascita"));
						d.setSesso(rs.getString("g.sesso"));
						d.setEmail(rs.getString("a.email"));
						d.setUsername(rs.getString("a.username"));
						d.setPassword(rs.getString("a.pwd"));
						d.setTipo_permesso(rs.getString("p.tipo"));
						
						arrADDTO.add(d);
					}
				}catch(SQLException e) {
					e.printStackTrace();
				}
				
				request.setAttribute("accDTO", arrADDTO);
				rd = request.getRequestDispatcher("GetAccountsFile.jsp");
				rd.forward(request, response);
			}
			else if(a.getTipo_permesso().equals("GUEST")) {
				a = new Account();
				a = (Account) session.getAttribute("sessionRole");
				rs = ra.getAccount(a);
				
				g = new Gestore();
				try {
					if(rs.next()) {
						g.setNome(rs.getString("g.nome"));
						g.setCognome(rs.getString("g.cognome"));
						g.setCf(rs.getString("g.cf"));
						g.setData_nascita(rs.getDate("g.data_nascita"));
						g.setSesso(rs.getString("g.sesso"));
						
						a = new Account(); //do una nuova istanza
						a.setEmail(rs.getString("a.email"));
						a.setUsername(rs.getString("a.username"));
						a.setPassword(rs.getString("a.pwd"));
						a.setTipo_permesso(rs.getString("p.tipo"));
					}
				}catch(SQLException e) {
					e.printStackTrace();
				}
				
				request.setAttribute("account", a);
				request.setAttribute("gestore", g);
				rd = request.getRequestDispatcher("GetAccountsFile.jsp");
				rd.forward(request, response);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
