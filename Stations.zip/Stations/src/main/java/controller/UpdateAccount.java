package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Account;
import model.Gestore;
import model.RepoAccount;
import model.RepoGestore;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class UpdateAccount
 */
public class UpdateAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateAccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Gestore g = new Gestore();
		Account a = new Account();
		
		String cf = request.getParameter("cf");
		
		RepoAccount ra = new RepoAccount();
		RequestDispatcher rd;
		ResultSet rs;
		
		rs = ra.getAccount(cf);
		
		try {
			if(rs.next()) {
				g.setNome(rs.getString("g.nome"));
				g.setCognome(rs.getString("g.cognome"));
				g.setCf(rs.getString("g.cf"));
				g.setData_nascita(rs.getDate("g.data_nascita"));
				g.setSesso(rs.getString("g.sesso"));
				
				a.setId(rs.getString("a.id"));
				a.setEmail(rs.getString("a.email"));
				a.setUsername(rs.getString("a.username"));
				a.setPassword(rs.getString("a.pwd"));
				a.setTipo_permesso(rs.getString("p.tipo"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("gestore", g);
		request.setAttribute("account", a);
		request.setAttribute("IU", 1);
		rd = request.getRequestDispatcher("InsertManagerFile.jsp");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPut(request, response);
	}
	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Gestore g_old = new Gestore();
		Gestore g_new = new Gestore();
		
		Account a_old = new Account();
		Account a_new = new Account();
		
		RequestDispatcher rd;
		
		a_old.setTipo_permesso(request.getParameter("role_old"));
		
		g_old.setNome(request.getParameter("name_old"));
		g_old.setCognome(request.getParameter("surname_old"));
		g_old.setCf(request.getParameter("cf_old"));
		g_old.setData_nascita(Date.valueOf(request.getParameter("date_old")));
		g_old.setSesso(request.getParameter("sex_old"));
		
		a_old.setUsername(request.getParameter("username_old"));
		a_old.setPassword(request.getParameter("password_old"));
		a_old.setEmail(request.getParameter("email_old"));
		a_old.setId(request.getParameter("id_old"));
		
		String role = request.getParameter("role");
		String name = request.getParameter("name");
		String surname = request.getParameter("surname");
		String cf = request.getParameter("cf");
		String date = request.getParameter("date");
		String sex = request.getParameter("sex");
		
		String user = request.getParameter("username");
		String pwd = request.getParameter("password");
		String email = request.getParameter("email");
		String id = request.getParameter("id");
		
		
		if(!role.isEmpty()) {
			a_new.setTipo_permesso(role);
		}
		else {
			a_new.setTipo_permesso(a_old.getTipo_permesso());
		}
		
		if(!name.isEmpty()) {
			g_new.setNome(name);
		}
		else {
			g_new.setNome(g_old.getNome());
		}
		
		if(!surname.isEmpty()) {
			g_new.setCognome(surname);
		}
		else {
			g_new.setCognome(g_old.getCognome());
		}
		
		if(!cf.isEmpty()) {
			g_new.setCf(cf);
		}
		else {
			g_new.setCf(g_old.getCf());
		}
		
		if(!date.isEmpty()) {
			g_new.setData_nascita(Date.valueOf(date));
		}
		else {
			g_new.setData_nascita(g_old.getData_nascita());
		}
		
		if(!sex.isEmpty()) {
			g_new.setSesso(sex);
		}
		else {
			g_new.setSesso(g_old.getSesso());
		}
		
		if(!user.isEmpty()) {
			a_new.setUsername(user);
		}
		else {
			a_new.setUsername(a_old.getUsername());
		}
		
		if(!pwd.isEmpty()) {
			a_new.setPassword(pwd);
		}
		else {
			a_new.setPassword(a_old.getPassword());
		}
		
		if(!email.isEmpty()) {
			a_new.setEmail(email);
		}
		else {
			a_new.setEmail(a_old.getEmail());
		}
		
		if(!id.isEmpty()) {
			a_new.setId(id);
		}
		else {
			a_new.setId(a_old.getId());
		}
		
		
		if(g_new.equals(g_old) && a_new.equals(a_old)) {
			request.setAttribute("msg", "MODIFICA GESTORE E ACCOUNT ANNULLATA");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
		else {
			RepoGestore rg = new RepoGestore();
			RepoAccount ra = new RepoAccount();
			ResultSet rs;
			
			rs = ra.getPermesso(a_new);
			int idPer = 0;
			
			try {
				if(rs.next()) {
					idPer = rs.getInt("id");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			if(rg.updateGestore(g_new, g_old.getCf())>0) {
				if(ra.updateAccount(a_new, a_old.getEmail(), idPer)>0) {
					request.setAttribute("msg", "GESTORE E/O ACCOUNT MODIFICATI CON SUCCESSO");
					rd = request.getRequestDispatcher("SuccessFile.jsp");
					rd.forward(request, response);
				}
				else {
					request.setAttribute("msg", "MODIFICA ACCOUNT FALLITA");
					rd = request.getRequestDispatcher("ErrorFile.jsp");
					rd.forward(request, response);
				}
			}
			else {
				request.setAttribute("msg", "MODIFICA GESTORE FALLITA");
				rd = request.getRequestDispatcher("ErrorFile.jsp");
				rd.forward(request, response);
			}
			
		}
	}

}
