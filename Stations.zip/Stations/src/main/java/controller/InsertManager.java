package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Account;
import model.Gestore;
import model.RepoAccount;
import model.RepoGestore;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class InsertManager
 */
public class InsertManager extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertManager() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Gestore g = new Gestore();
		Account a = new Account();
		RequestDispatcher rd;
		
		g.setNome(request.getParameter("name"));
		g.setCognome(request.getParameter("surname"));
		g.setCf(request.getParameter("cf"));
		g.setData_nascita(Date.valueOf(request.getParameter("date"))); //converto in data
		g.setSesso(request.getParameter("sex"));
		
		a.setId(request.getParameter("id"));
		a.setUsername(request.getParameter("username"));
		a.setPassword(request.getParameter("password"));
		a.setEmail(request.getParameter("email"));
		a.setTipo_permesso(request.getParameter("role"));
		
		RepoGestore rg = new RepoGestore();
		RepoAccount ra = new RepoAccount();
		
		if(rg.insertGestore(g)>0) {
			
			
			ResultSet rs = ra.getPermesso(a);
			int idPer = 0;
			
			try {
				if(rs.next()) {
					idPer = rs.getInt("id"); //trovo l'index del permesso recuperato dalla request
					System.out.println("ID PERMESSO RICEVUTO: " + idPer);
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			rs = rg.getGestore(g); //trovo l'index del gestore aggiunto
			int idGes = 0;
			
			try {
				if(rs.next()) {
					idGes = rs.getInt("id");
					System.out.println("ID GESTORE RICEVUTO: " + idGes);
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			if(ra.insertAccount(a, idGes, idPer)>0) {
				request.setAttribute("msg", "GESTORE INSERITO CON SUCCESSO");
				rd = request.getRequestDispatcher("SuccessFile.jsp");
				rd.forward(request, response);
				
			}
			else {
				request.setAttribute("msg", "INSERIMENTO ACCOUNT FALLITO");
				rd = request.getRequestDispatcher("ErrorFile.jsp");
				rd.forward(request, response);
			}
		}
		else {
			request.setAttribute("msg", "INSERIMENTO GESTORE FALLITO");
			rd = request.getRequestDispatcher("ErrorFile.jsp");
			rd.forward(request, response);
		}
		
	}

}
