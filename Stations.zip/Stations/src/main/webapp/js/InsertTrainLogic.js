/**
 * 
 */

 function checkSeries(){
	 var series = document.insert.series;
	 var check = new RegExp('^[A-Z]{3}[0-9]{5}$');
	 var error = document.getElementById("errSeries");
	 
	 if(!check.test(series.value)){
		 series.style.backgroundColor = "red";
		 error.innerHTML = "3 caratteri maiusc e 5 numeri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 series.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkProd(){

    var error = document.getElementById("errProd");

    var anno_prod = document.insert.prod;

    if(anno_prod.value == ""){ //controlla prima se la data input è stata inserita
        error.innerHTML="Inserisci l'anno di produzione";
        error.style.color="#DC5959";
        return false;
    }
    else{
        error.innerHTML="Giusto";
        error.style.color = "darkgreen";
        return true;
    }
}

function checkVelocity(){
	 var velocity = document.insert.velocity;
	 var error = document.getElementById("errVelocity");
	 
	 if(velocity.value == "" || velocity.value == 0){
		 velocity.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci la velocità";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 velocity.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 

 function checkChoose(){
	 var capacity = document.insert.choose;
	 var passengers = document.getElementById("pas");
	 var goods = document.getElementById("gds");
	 var error = document.getElementById("errChoose");
	 
	 if(capacity.value == 'P'){
		 
		 goods.style.display = "none";
		 passengers.style.display = "flex";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
	 else if(capacity.value == 'G'){
		 
		 passengers.style.display = "none";
		 goods.style.display = "flex";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
	 else if(capacity.value == ""){
		 error.innerHTML = "Devi scegliere";
		 error.style.color = "#DC5959";
		 return false;
	 }
 }
 
 function checkPassengers(){
	 var passengers = document.insert.passengers;
	 var error = document.getElementById("errPassenger");
	 
	 if(passengers.value < 0){
		 passengers.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci la capienza passeggeri";
		 error.style.color = "#DC5959";
		 return false; 
	 }
	 else{
		 passengers.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkGoods(){
	 var goods = document.insert.goods;
	 var error = document.getElementById("errGoods");
	 
	 if(goods.value < 0){
		 goods.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci la capienza merci";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 goods.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function sendForm(){
	 var flag;
	 var error = document.getElementById("errForm");
	 
	 var functions = [checkSeries, checkProd, checkVelocity, checkChoose, checkPassengers, checkGoods]; //array di funzioni
	 var results = []; //array di risultati da contenere
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i](); //passa i valori da 
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error.innerHTML = "Qualcosa è andato storto"
		 error.style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true; 
 }
 
 function sureReset(){
	 var sure = confirm("Sei sicuro di voler cancellare i valori inseriti?");
	 
	 if(sure == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }