/**
 * 
 */

 function sureLogout(){
	 var sure = confirm("Sei sicuro di voler procedere con il logout?");
	 
	 if(sure == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }