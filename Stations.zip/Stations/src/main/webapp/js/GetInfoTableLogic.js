/**
 * 
 */

 function deleteOver(index){
	 
	 var over = document.getElementsByClassName("bintrash");
	 
	 
	 
	 over[index].style.display ="block";
	 
 } 
 
 function deleteOut(index){
	 
	 var over = document.getElementsByClassName("bintrash");
	 
	  
	 over[index].style.display ="none";
 }
 
 function updateOver(index){
	 
	 var over = document.getElementsByClassName("engkey");
	 
	 
	 
	 over[index].style.display ="block";
	 
 } 
 
 function updateOut(index){
	 
	 var over = document.getElementsByClassName("engkey");
	 
	  
	 over[index].style.display ="none";
 }
 
 function verifyDelete(){
	 var verify = confirm("Sei sicuro di voler eliminare questa riga?");
	 
	 if(verify == true){
		 console.log("Eliminazione in corso...");
		 return true;
	 }
	 else{
		 console.log("Eliminazione annullata");
		 return false;
	 }
 }