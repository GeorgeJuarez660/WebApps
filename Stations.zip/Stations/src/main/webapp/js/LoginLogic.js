/**
 * 
 */


function checkUsername(){
    var user = document.reg.username;
    var check= new RegExp('^[a-z]{3,15}$');
    var error = document.getElementById("errUser");

    if(!check.test(user.value)){
        user.style.backgroundColor ="red";
        error.innerHTML = "Inserisci l'username corretto";
        error.style.color="#DC5959";
        return false;
    }
    else{
        user.style.backgroundColor="transparent";
        error.innerHTML = "Giusto";
        error.style.color="darkgreen";
        return true;
    }

}

function checkPassword(){
    var password = document.reg.password;
    var check = new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%])(?=.*[0-9]).{8,20}$'); //tra le parentesi tonde vuol dire l'obbligo
    var error = document.getElementById("errPwd");

    if(!check.test(password.value)){
        password.style.backgroundColor ="red";
        error.innerHTML = "Inserisci la password corretta";
        error.style.color= "#DC5959";
        return false;
    }
    else{
        password.style.backgroundColor="transparent";
        error.innerHTML = "Giusto";
        error.style.color="darkgreen";
        return true;
    }

}


function sendForm(){

    var flag;
    var error = document.getElementById("errForm")
    var functions = [checkUsername, checkPassword]; //le funzioni le metto all'interno del vettore cosi per andare a ciclarli

    var results = []; //vettore di risultati che mi serviranno per conservare i risultati delle funzioni

    for (var i=0; i<functions.length; i++) {
        flag =  functions[i](); //li vado a ciclare cosi che tutti i risultati delle funzioni andranno nel flag e poi nel nuovo vettore
        results[i] = flag;
        
    }

    if (results.includes(false)) { //se il vettore di risultati contiene almeno un false
        error.innerHTML = "Qualcosa è andato storto";
        error.style.color = "red";
        return false;
    }

    //se tutte le verifiche hanno successo, continua l'esecuzione del codice successivo qui

    error.innerHTML = "Invio del form in corso...";
    error.style.color="darkgreen";
    return true;
}