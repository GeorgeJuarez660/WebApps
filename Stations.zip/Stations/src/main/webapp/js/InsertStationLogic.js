/**
 * 
 */

 function checkName(){
	 var name = document.insert.name;
	 var check = new RegExp('^[a-z. ]{3,50}$', 'i');
	 var error = document.getElementById("errName");
	 
	 if(!check.test(name.value)){
		 name.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci 50 caratteri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 name.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkCity(){
	 var city = document.insert.city;
	 var check = new RegExp('^[a-z ]{3,50}$', 'i');
	 var error = document.getElementById("errCity");
	 
	 if(!check.test(city.value)){
		 city.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci 50 caratteri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 city.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkDate(){

    var error = document.getElementById("errDate");

    var anno_aper = document.insert.date;

    if(anno_aper.value == ""){ //controlla prima se la data input è stata inserita
        error.innerHTML="Inserisci l'anno di apertura";
        error.style.color="#DC5959";
        return false;
    }
    else{
        error.innerHTML="Giusto";
        error.style.color = "darkgreen";
        return true;
    }
}


 

 
 function sendForm(){
	 var flag;
	 var error = document.getElementById("errForm");
	 
	 var functions = [checkName, checkCity, checkDate]; //array di funzioni
	 var results = []; //array di risultati da contenere
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i](); //passa i valori da 
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error.innerHTML = "Qualcosa è andato storto"
		 error.style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true; 
 }
 
 function sureReset(){
	 var sure = confirm("Sei sicuro di voler cancellare i valori inseriti?");
	 
	 if(sure == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }