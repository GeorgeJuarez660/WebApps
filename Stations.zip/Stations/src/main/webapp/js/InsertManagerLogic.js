/**
 * 
 */

 function checkRole(){
	 var role = document.insert.role;
	 var error = document.getElementById("errRole");
	 
	 if(role.value == ""){
		 error.innerHTML = "Devi scegliere";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkName(){
	 var name = document.insert.name;
	 var check = new RegExp('^[a-z]{3,50}$', 'i');
	 var error = document.getElementById("errName");
	 
	 if(!check.test(name.value)){
		 name.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci 50 caratteri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 name.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkSurname(){
	 var surname = document.insert.surname;
	 var check = new RegExp('^[a-z]{3,50}$', 'i');
	 var error = document.getElementById("errSurname");
	 
	 if(!check.test(surname.value)){
		 surname.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci 50 caratteri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 surname.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkCF(){
    var cf = document.insert.cf;
    var check= new RegExp('^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$');
    var error = document.getElementById("errCF");

    if(!check.test(cf.value)){
        cf.style.backgroundColor ="red";
        error.innerHTML = "Inserisci il cf corretto";
        error.style.color = "#DC5959";
        return false;
    }
    else{
        cf.style.backgroundColor = "transparent";
        error.innerHTML = "Giusto";
        error.style.color = "darkgreen";
        return true;
    }
 }
 
 function checkDate(){
    var error = document.getElementById("errDate");

    var date = document.insert.date;
    var data_corrente = new Date(); //imposto la data corrente: di default prende la data di oggi

    if(date.value == ""){ //controlla prima se la data input è stata inserita
        error.innerHTML = "Inserisci la data di nascita";
        error.style.color = "#DC5959";
        return false;
    }
 
    var data_immessa = new Date(date.value);  //imposto la data immessa

    var differenza = data_corrente - data_immessa; //faccio la differenza 

    var eta = differenza / (1000 * 60 * 60 * 24 * 365.25); //in anni millisecondi

    if(eta<18){
        error.innerHTML="Non sei maggiorenne";
        error.style.color="#DC5959";
        return false;
    }
    else{
        error.innerHTML = "Giusto";
        error.style.color = "darkgreen";
        return true;
    }
 }
 
 function checkSex(){
	 var sex = document.insert.sex;
	 var error = document.getElementById("errSex");
	 
	 if(sex.value == ""){
		 error.innerHTML = "Devi scegliere";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkUsername(){
    var username = document.insert.username;
    var check= new RegExp('^[a-z0-9]{3,50}$', 'i');
    var error = document.getElementById("errUser");

    if(!check.test(username.value)){
        username.style.backgroundColor ="red";
        error.innerHTML = "Inserisci l'username corretto";
        error.style.color="#DC5959";
        return false;
    }
    else{
        username.style.backgroundColor = "transparent";
		error.innerHTML = "Giusto";
		error.style.color = "darkgreen";
		return true;
    }

 }
 
 function checkPassword(){
    var password = document.insert.password;
    var check= new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%])(?=.*[0-9]).{8,20}$');
    var error = document.getElementById("errPwd");

    if(!check.test(password.value)){
        password.style.backgroundColor ="red";
        error.innerHTML = "Inserisci la pwd corretta";
        error.style.color="#DC5959";
        return false;
    }
    else{
        password.style.backgroundColor = "transparent";
		error.innerHTML = "Giusto";
		error.style.color = "darkgreen";
		return true;
    }

 }
 
 function checkConfPassword(){
    var conf_password = document.insert.conf_password;
    var password = document.insert.password;
    var error = document.getElementById("errConfPwd");

    if(conf_password.value == "" || password.value != conf_password.value){ //se non sono uguali
        conf_password.style.backgroundColor ="red";
        error.innerHTML = "Le password non coincidono";
        error.style.color="#DC5959";
        return false;
    }
    else{
        conf_password.style.backgroundColor = "transparent";
		error.innerHTML = "Giusto";
		error.style.color = "darkgreen";
		return true;
    }

 }
 
 function checkEmail(){
    var email = document.insert.email;
    var error = document.getElementById("errEmail");

    if(!email.value.endsWith("@gmail.com")){ //se finisce con @gmail.com
        email.style.backgroundColor ="red";
        error.innerHTML = "Inserisci l'email valida";
        error.style.color="#DC5959";
        return false;
    }
    else{
        email.style.backgroundColor = "transparent";
		error.innerHTML = "Giusto";
		error.style.color = "darkgreen";
		return true;
    }

 }
 
 function checkID(){
    var id = document.insert.id;
    var check= new RegExp('^[A-Z]{3}$');
    var error = document.getElementById("errID");

    if(!check.test(id.value)){ //se finisce con @gmail.com
        id.style.backgroundColor ="red";
        error.innerHTML = "Inserisci 3 caratteri maiusc";
        error.style.color="#DC5959";
        return false;
    }
    else{
        id.style.backgroundColor = "transparent";
		error.innerHTML = "Giusto";
		error.style.color = "darkgreen";
		return true;
    }

 }
 
 
 function sendForm(){
	 var flag;
	 var error = document.getElementById("errForm");
	 
	 var functions = [checkRole, checkName, checkSurname, checkCF, checkDate, checkSex, checkUsername, 
	                  checkPassword, checkConfPassword, checkEmail, checkID];
	 var results = [];
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i]();
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error.innerHTML = "Qualcosa è andato storto";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true;
 }
 
 function sureReset(){
	 var sure = confirm("Sei sicuro di voler cancellare i valori inseriti?");
	 
	 if(sure == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }
 
 function verifyUpdate(){
	 var verify = confirm("Sei sicuro di voler modificare questa riga?");
	 
	 if(verify == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }
 
 