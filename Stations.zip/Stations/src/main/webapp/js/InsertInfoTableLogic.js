/**
 * 
 */

 function checkCompany(){
	 var company = document.insert.company;
	 var check = new RegExp('^[a-z ]{3,100}$', 'i');
	 var error = document.getElementById("errCompany");
	 
	 if(!check.test(company.value)){
		 company.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci da 2-100 caratteri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 company.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkSeries(){
	 var series = document.insert.series;
	 var check = new RegExp('^[A-Z]{3}[0-9]{5}$');
	 var error = document.getElementById("errSeries");
	 
	 if(!check.test(series.value)){
		 series.style.backgroundColor = "red";
		 error.innerHTML = "3 caratteri maiusc e 5 numeri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 series.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkType(){
    var type = document.insert.type;
    var check= new RegExp('^[A-Z]{3}$');
    var error = document.getElementById("errType");

    if(!check.test(type.value)){ //se finisce con @gmail.com
        type.style.backgroundColor ="red";
        error.innerHTML = "Inserisci 3 caratteri maiusc";
        error.style.color="#DC5959";
        return false;
    }
    else{
        type.style.backgroundColor = "transparent";
		error.innerHTML = "Giusto";
		error.style.color = "darkgreen";
		return true;
    }

 }
 
 function checkDepst(){
	 var depst = document.insert.depst;
	 var check = new RegExp('^[a-z. ]{3,50}$', 'i');
	 var error = document.getElementById("errDepst");
	 
	 if(!check.test(depst.value)){
		 depst.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci 50 caratteri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 depst.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkArrst(){
	 var arrst = document.insert.arrst;
	 var check = new RegExp('^[a-z. ]{3,50}$', 'i');
	 var error = document.getElementById("errArrst");
	 
	 if(!check.test(arrst.value)){
		 arrst.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci 50 caratteri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 arrst.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkStatus(){
	 var status = document.insert.status;
	 var time = document.getElementById("time");
	 var track = document.getElementById("track");
	 var error = document.getElementById("errStatus");
	 
	 if(status.value == 'E' || status.value == 'R'){
		 
		 time.style.display = "flex";
		 track.style.display = "flex";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
	 else if(status.value == 'C'){
		 
		 time.style.display = "none";
		 track.style.display = "none";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
	 else if(status.value == ""){
		 error.innerHTML = "Devi scegliere";
		 error.style.color = "#DC5959";
		 return false;
	 }
 }
 
 function checkTime(){

    var error = document.getElementById("errTime");
	var status = document.insert.status;

    var hours = document.insert.hours;
    var minutes = document.insert.minutes;
    var seconds  = document.insert.seconds;


    if(hours.value>23 || minutes.value>59 || seconds.value>59){ //controlla prima se il time input è stato inserito
        error.innerHTML="Inserisci l'orario";
        error.style.color="#DC5959";
        return false;
    }
    else{
        error.innerHTML="Giusto";
        error.style.color = "darkgreen";
        return true;
    }
 }

 function checkTrack(){
	 var track = document.insert.track;
	 var status = document.insert.status;
	 var error = document.getElementById("errTrack");
	 
	 if(track.value == ""  && status.value == 'E' || status.value == 'R'){
		 track.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci il numero del binario";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 track.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkAcc(){
    var acc = document.insert.acc;
    var check= new RegExp('^[A-Z]{3}$');
    var error = document.getElementById("errAcc");

    if(!check.test(acc.value)){ //se finisce con @gmail.com
        acc.style.backgroundColor ="red";
        error.innerHTML = "Inserisci 3 caratteri maiusc";
        error.style.color="#DC5959";
        return false;
    }
    else{
        acc.style.backgroundColor = "transparent";
		error.innerHTML = "Giusto";
		error.style.color = "darkgreen";
		return true;
    }

 }
 
 function sendForm(){
	 var flag;
	 var error = document.getElementById("errForm");
	 
	 var functions = [checkCompany, checkSeries, checkType, checkDepst, checkArrst, checkStatus, checkTime,
	                  checkTrack, checkAcc]; //array di funzioni
	 var results = []; //array di risultati da contenere
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i](); //passa i valori da 
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error.innerHTML = "Qualcosa è andato storto"
		 error.style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true; 
 }
 
 function sureReset(){
	 var sure = confirm("Sei sicuro di voler cancellare i valori inseriti?");
	 
	 if(sure == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }
 
 function verifyUpdate(){
	 var verify = confirm("Sei sicuro di voler modificare questa riga?");
	 
	 if(verify == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }