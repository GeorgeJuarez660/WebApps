/**
 * 
 */

 function checkID(){
    var id = document.insert.id;
    var check= new RegExp('^[A-Z]{3}$');
    var error = document.getElementById("errID");

    if(!check.test(id.value)){ //se finisce con @gmail.com
        id.style.backgroundColor ="red";
        error.innerHTML = "Inserisci 3 caratteri maiusc";
        error.style.color="#DC5959";
        return false;
    }
    else{
        id.style.backgroundColor = "transparent";
		error.innerHTML = "Giusto";
		error.style.color = "darkgreen";
		return true;
    }

 }

 function checkName(){
	 var name = document.insert.name;
	 var check = new RegExp('^[a-z]{3,30}$');
	 var error = document.getElementById("errName");
	 
	 if(!check.test(name.value)){
		 name.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci 30 caratteri minusc";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 name.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function checkDesc(){
	 var desc = document.insert.desc;
	 var check = new RegExp('^[a-z0-9]{0,150}$', 'i');
	 var error = document.getElementById("errDesc");
	 
	 if(!check.test(desc.value)){
		 desc.style.backgroundColor = "red";
		 error.innerHTML = "Limite di 150 caratteri";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 desc.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function sendForm(){
	 var flag;
	 var error = document.getElementById("errForm");
	 
	 var functions = [checkID, checkName, checkDesc]; //array di funzioni
	 var results = []; //array di risultati da contenere
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i](); //passa i valori da 
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error.innerHTML = "Qualcosa è andato storto"
		 error.style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true; 
 }
 
 function sureReset(){
	 var sure = confirm("Sei sicuro di voler cancellare i valori inseriti?");
	 
	 if(sure == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }