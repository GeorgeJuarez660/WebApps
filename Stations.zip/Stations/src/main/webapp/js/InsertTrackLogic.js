/**
 * 
 */

 function checkNumber(){
	 var track = document.insert.number;
	 var error = document.getElementById("errNumber");
	 
	 if(track.value == "" || track.value == 0){
		 track.style.backgroundColor = "red";
		 error.innerHTML = "Inserisci il numero del binario";
		 error.style.color = "#DC5959";
		 return false;
	 }
	 else{
		 track.style.backgroundColor = "transparent";
		 error.innerHTML = "Giusto";
		 error.style.color = "darkgreen";
		 return true;
	 }
 }
 
 function sendForm(){
	 var flag;
	 var error = document.getElementById("errForm");
	 
	 flag = checkNumber(); //non usiamo l'array perchè è una sola funzione
	 
	 if(!flag){
		 error.innerHTML = "Qualcosa è andato storto"
		 error.style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true; 
 }
 
 function sureReset(){
	 var sure = confirm("Sei sicuro di voler cancellare i valori inseriti?");
	 
	 if(sure == true){
		 return true;
	 }
	 else{
		 return false;
	 }
 }